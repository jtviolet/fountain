var User = require('../app/server/models/User');

// Load the AWS SDK
var AWS = require('aws-sdk'),
  region = process.env.AWS_REGION;

// Create a Secrets Manager client
var client = new AWS.SecretsManager({
  region: region
});

// Load the credentials for the initial admin user of the registration portal
client.getSecretValue({ SecretId: process.env.AWS_SM_ADMIN_USER }, function (err, data) {
  if (err) {
    throw err;
  }
  else {
    const secret = JSON.parse(data.SecretString);
    // Create a default admin user
    // if there isn't already one
    User
      .findOne({
        email: secret.email
      })
      .exec(function (err, user) {
        if (!user) {
          var adminUser = new User();
          adminUser.email = secret.email;
          adminUser.password = User.generateHash(secret.password);
          adminUser.admin = true;
          adminUser.verified = true;
          adminUser.save(function (err) {
            if (err) {
              console.log(err);
            }
          });
        }
      });
  }
});


